#include <iostream>
using namespace std;

int main() {
    cout << "I love parallel programming!" << endl;
    return 0;
}