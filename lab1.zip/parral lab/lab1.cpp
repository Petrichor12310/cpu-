#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;

// 1. 平凡算法：外层循环 i (列)，内层循环 j (行) [cite: 382]
void trivial_algo(int n, const vector<double>& b, const vector<double>& a, vector<double>& sum) {
    for (int i = 0; i < n; i++) {
        sum[i] = 0.0;
        for (int j = 0; j < n; j++) {
            sum[i] += b[j * n + i] * a[j]; // 逐列访问矩阵 [cite: 393]
        }
    }
}

// 2. Cache优化算法：外层循环 j (行)，内层循环 i (列) [cite: 395]
void cache_opt_algo(int n, const vector<double>& b, const vector<double>& a, vector<double>& sum) {
    for (int i = 0; i < n; i++) sum[i] = 0.0;
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            sum[i] += b[j * n + i] * a[j]; // 逐行访问矩阵 [cite: 400]
        }
    }
}

int main() {
    int N = 512; // 也可以改为 4096，每次测一个规模
    vector<double> B(N * N), A(N), sum(N);

    // 数据初始化
    for (int i = 0; i < N; i++) {
        A[i] = 1.0; 
        for (int j = 0; j < N; j++) B[j * N + i] = 1.0;
    }

    // --- 关键：每次测试时，注释掉其中一个，只留一个运行 ---
    
    //运行平凡算法 10 次（增加样本量让 VTune 抓得更准）
    for (int r = 0; r < 1000; r++) {
        trivial_algo(N, B, A, sum);
    }//

    /*运行优化算法时，注释掉上面的 trivial，取消下面的注释
    for (int r = 0; r < 1000; r++) {
        cache_opt_algo(N, B, A, sum);
    }
    */
// 在所有循环结束后加一句
cout << "Check sum: " << sum[0] << endl;
    return 0;
}