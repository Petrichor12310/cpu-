#include <iostream>
#include <vector>

using namespace std;

// 纯正的递归分治算法：只读输入数组，不产生任何数据修改
double true_recursive_sum(const vector<double>& a, int left, int right) {
    // 递归终止条件：细分到只剩一个元素时直接返回
    if (left == right) {
        return a[left];
    }
    
    // 划分子问题
    int mid = left + (right - left) / 2;
    
    // 递归求解左右两部分
    double sum_left = true_recursive_sum(a, left, mid);
    double sum_right = true_recursive_sum(a, mid + 1, right);
    
    // 合并结果
    return sum_left + sum_right;
}

// 包装函数，方便外层循环调用
double recursive_wrapper(const vector<double>& a) {
    if (a.empty()) return 0.0;
    return true_recursive_sum(a, 0, a.size() - 1);
}

int main() {
    int N = 65536; 
    vector<double> A(N, 1.0);
    int repeat = 100000;
    double final_sum = 0.0;

    // --- 测试三：纯净的递归/分治算法 ---
    // 此时不需要在循环内 copy 数组，彻底消除了内存带宽污染
    for (int r = 0; r < repeat; r++) {
        final_sum += recursive_wrapper(A);
    }

    cout << "Final Sum Check: " << final_sum << endl;
    return 0;
}