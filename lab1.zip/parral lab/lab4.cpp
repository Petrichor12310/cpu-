#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

// 1. 平凡算法：严格串行累加
double trivial_sum(int n, const vector<double>& a) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return sum;
}

// 2. 优化算法：4路循环展开，改变了加法结合顺序
double unroll_sum(int n, const vector<double>& a) {
    double sum1 = 0.0, sum2 = 0.0, sum3 = 0.0, sum4 = 0.0;
    int i = 0;
    for (; i <= n - 4; i += 4) {
        sum1 += a[i];
        sum2 += a[i + 1];
        sum3 += a[i + 2];
        sum4 += a[i + 3];
    }
    for (; i < n; i++) sum1 += a[i]; // 尾部处理
    return (sum1 + sum2) + (sum3 + sum4);
}

int main() {
    int N = 65536; 
    vector<double> A(N);

    // 构造极端数据集：每 4 个元素构成一个周期 [1e16, 1.0, -1e16, 1.0]
    // 数学上的真实和：每个周期和为 2.0，总周期数为 N/4 (16384)。
    // 真实理论和 = 16384 * 2.0 = 32768.0
    for (int i = 0; i < N; i += 4) {
        A[i]     = 1e16;
        A[i + 1] = 1.0;
        A[i + 2] = -1e16;
        A[i + 3] = 1.0;
    }

    double res_trivial = trivial_sum(N, A);
    double res_unroll  = unroll_sum(N, A);

    cout << fixed << setprecision(2);
    cout << "理论真实数学和 (Theoretical True Sum): " << (double)(N / 2) << endl;
    cout << "平凡算法求和   (Trivial Sum)         : " << res_trivial << endl;
    cout << "4路展开求和    (Unroll Sum)          : " << res_unroll << endl;

    return 0;
}