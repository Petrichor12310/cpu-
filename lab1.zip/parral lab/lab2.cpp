#include <iostream>
#include <vector>

using namespace std;

// 1. 平凡算法：单路链式累加。存在严格的数据依赖，流水线容易停顿
double trivial_sum(int n, const vector<double>& a) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += a[i]; 
    }
    return sum;
}

// 2. 优化算法 (ILP)：4路循环展开 + 多独立累加器。打破依赖，利用超标量并发
double unroll_sum(int n, const vector<double>& a) {
    double sum1 = 0.0, sum2 = 0.0, sum3 = 0.0, sum4 = 0.0;
    int i = 0;
    for (; i <= n - 4; i += 4) {
        sum1 += a[i];
        sum2 += a[i + 1];
        sum3 += a[i + 2];
        sum4 += a[i + 3];
    }
    for (; i < n; i++) sum1 += a[i]; // 处理尾部
    return sum1 + sum2 + sum3 + sum4;
}

// 3. 递归/分治算法：原地保存中间结果，利用空间局部性
// 注意：此算法会修改原数组内容
double recursive_sum(int n, vector<double>& a) {
    // 步长逐次翻倍，逻辑等价于自底向上的二分归并求和
    for (int step = 1; step < n; step *= 2) {
        // 内层循环连续访问，保证 L1 Cache 的空间局部性
        for (int i = 0; i < n; i += 2 * step) {
            a[i] += a[i + step]; // 原地保存中间结果
        }
    }
    return a[0];
}

int main() {
    int N = 65536; // 2的16次方，大小约512KB，完美匹配L2 Cache
    vector<double> A(N, 1.0);
    vector<double> temp_A(N); // 用于递归算法的工作数组，防止原数据被破坏

    int repeat = 100000;
    double final_sum = 0.0;

    // ================= VTune 测试开关 =================
    // 每次使用 VTune 分析时，只取消注释其中一个块

    
    // --- 测试一：平凡算法 ---
    for (int r = 0; r < repeat; r++) {
        final_sum += trivial_sum(N, A);
    }
    

    
    /* --- 测试二：循环展开与 ILP ---
    for (int r = 0; r < repeat; r++) {
        final_sum += unroll_sum(N, A);
    }*/
    
    
     
    /* --- 测试三：递归/分治算法 ---
    for (int r = 0; r < repeat; r++) {
        // 每次需重置数组，因为递归算法是原地修改
        copy(A.begin(), A.end(), temp_A.begin()); 
        final_sum += recursive_sum(N, temp_A);
    }
    /*/

    cout << "Final Sum Check: " << final_sum << endl;

    return 0;
}